20 test case cho bài Tổng hai số
Mỗi test gồm một file .in và một file .out cùng số thứ tự.
Định dạng input: hai số nguyên a và b trên một dòng.
Định dạng output: một dòng chứa a + b.
Lưu ý: test 17-20 cần kiểu số nguyên đủ lớn (64-bit hoặc arbitrary precision).
