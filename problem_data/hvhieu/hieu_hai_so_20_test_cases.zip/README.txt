20 test cases cho bai toan tinh hieu a - b.
Moi test gom cap file NNN.in va NNN.out.
Input: hai so nguyen a b tren mot dong.
Output: gia tri a - b.
Rang buoc: -100 <= a, b <= 10^12.
